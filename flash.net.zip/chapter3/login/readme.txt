This example uses four files, which need to be placed in the specified folders:

	Login.swf - in a folder under wwwroot
	Login.aspx - in the same folder as Login.swf
	content.txt - in the C: drive root
	pass.txt - also in the C: drive root