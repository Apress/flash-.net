CREATE TABLE [dbo].[tblContacts] (
  [ContactId] [int] PRIMARY KEY  IDENTITY (1, 1),
  [FirstName] [varchar] (20) NOT NULL,
  [LastName] [varchar] (20) NOT NULL,
  [Email] [varchar] (50) NOT NULL,
  [Address] [varchar] (250) NOT NULL,
  [PhoneNo] [varchar] (25) NOT NULL,
)
GO

INSERT INTO tblContacts VALUES('Pallav', 'Nadhani', 'pallav@nadhani.com', '123 Bangur Avenue, Kolkata - 700055', '91-33-5552515');
INSERT INTO tblContacts VALUES('Vinay', 'Ranka', 'vinay_r@yahoo.com', '40-A Lake Town, Kolkata - 700055', '91-33-5554872');
INSERT INTO tblContacts VALUES('Sabya', 'Sachin', 'sabyasachin@hotmail.com', 'Sector 1, Tank 2, Salt Lake, Kolkata - 700032','91-33-5553575');
INSERT INTO tblContacts VALUES('Mrinal', 'Somani', 'mrinalsomani@yahoo.com','P-20, Bangur Avenue, Kolkata - 700055','91-33-5552376');
INSERT INTO tblContacts VALUES('Asok', 'Nadhani', 'akn@nadhani.com', '567/1, P-10, Bangur Avenue, Block B, Kolkata - 700055','91-33-5550651');
INSERT INTO tblContacts VALUES('Kisor', 'Nadhani', 'kkn@nadhani.com', '51/8, Bangur Avenue, Block D, Kolkata - 700055','9831060176');
INSERT INTO tblContacts VALUES('Nihit', 'Shah', 'nihitshah@vsnl.com', '11B, 4A, Shovabazar, Kolkata - 700019','91-33-5301266');

GO