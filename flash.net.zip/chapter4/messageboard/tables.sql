CREATE TABLE [dbo].[tblMessages] (
  [MessageID] [int] IDENTITY (1, 1) NOT NULL ,
  [ParentID] [int] NOT NULL ,
  [UserID] [int] NOT NULL ,
  [Subject] [varchar] (50) NOT NULL ,
  [MessageText] [varchar] (1024) NOT NULL ,
  [MessageDate] [datetime] NOT NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblUsers] (
  [UserID] [int] IDENTITY (1, 1) NOT NULL ,
  [Username] [varchar] (25) NOT NULL ,
  [Password] [varchar] (15) NOT NULL ,
  [Email] [varchar] (100) NOT NULL ,
  [DateAdded] [smalldatetime] NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[tblMessages] WITH NOCHECK ADD
  CONSTRAINT [PK_tblMessages] PRIMARY KEY  CLUSTERED
  (
    [MessageID]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[tblUsers] WITH NOCHECK ADD
  CONSTRAINT [PK_tblUsers] PRIMARY KEY  CLUSTERED
  (
    [UserID]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[tblMessages] WITH NOCHECK ADD
  CONSTRAINT [DF_tblMessages_ParentID] DEFAULT (0) FOR [ParentID],
  CONSTRAINT [DF_tblMessages_MessageDate] DEFAULT (getdate()) FOR [MessageDate]
GO

ALTER TABLE [dbo].[tblUsers] WITH NOCHECK ADD
  CONSTRAINT [DF_tblUsers_DateAdded] DEFAULT (getdate()) FOR [DateAdded]
GO

ALTER TABLE [dbo].[tblMessages] ADD
  CONSTRAINT [FK_tblMessages_tblUsers] FOREIGN KEY
  (
    [UserID]
  ) REFERENCES [dbo].[tblUsers] (
    [UserID]
  )
GO
