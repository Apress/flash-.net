CREATE TABLE [dbo].[tblContacts] (
	[ContactId] [int] PRIMARY KEY  IDENTITY (1, 1),
	[FirstName] [varchar] (20) NOT NULL,
	[LastName] [varchar] (20) NOT NULL,
	[Email] [varchar] (50) NOT NULL,
	[Address] [varchar] (250) NOT NULL,
	[PhoneNo] [varchar] (25) NOT NULL,
)
GO

INSERT INTO tblContacts VALUES('Pallav', 'Nadhani', 'pallav@nadhani.com', '272/1, 1st Floor Bangur Avenue, Block A, Kolkata - 700055','91-33-5742515');
INSERT INTO tblContacts VALUES('Vinay', 'Ranka', 'vinay_r@yahoo.com', '19-B, Lake Town, Kolkata - 700 055','91-33-5214872');
INSERT INTO tblContacts VALUES('Sabya', 'Sachin', 'sabyasachin@hotmail.com', 'Sector 3, Tank 7, Salt Lake, Kolkata - 700032','91-33-3593575');
INSERT INTO tblContacts VALUES('Mrinal', 'Somani', 'mrinalsomani@yahoo.com','P-60, Bangur Avenue, Block B, Kolkata - 700055','91-33-5742376');
INSERT INTO tblContacts VALUES('Asok', 'Nadhani', 'akn@nadhani.com', '272/1, P-10, Bangur Avenue, Block B, Kolkata - 700055','91-33-5740651');
INSERT INTO tblContacts VALUES('Kisor', 'Nadhani', 'kkn@nadhani.com', '47/1, Bangur Avenue, Block A, Kolkata - 700055','9831060176');
INSERT INTO tblContacts VALUES('Nihit', 'Shah', 'nihitshah@vsnl.com', '87A, 2C, Shovabazar, Kolkata - 700019','91-33-5301266');

GO